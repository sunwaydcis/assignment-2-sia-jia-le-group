module Main where
-- import Prelude hiding (filter)
import qualified Data.ByteString.Lazy as BL
import Data.Csv --this is from the cassava library
import qualified Data.Vector as V
-- import System.Directory (doesFileExist)
-- datatype to model a hospital dataset

-- Define the Date and Category types as before
type Date = String

data Category = Suspected | Probable | CovidPositive | NonCovid
    deriving (Eq, Show)

data HospitalDataset = HospitalDataset
    {date :: String,
     state :: String,
     beds :: Integer,
     beds_covid :: Integer,
     beds_noncrit :: Integer,
     admitted_pui :: Integer,
     admitted_covid :: Integer,
     admitted_total :: Integer,
     discharged_pui :: Integer,
     discharged_covid :: Integer,
     discharged_total :: Integer,
     hosp_covid :: Integer,
     hosp_pui :: Integer,
     hosp_noncovid :: Integer
    } deriving (Show, Eq)

--Define how to get a hospital dataset from a record (CSV row) by implementing the FromNameRecord type class
instance FromNameRecord HospitalDataset where
    parseNameRecord record =
        HospitalDataset
            <$> record .: "date"
            <*> record .: "state"
            <*> record .: "beds"
            <*> record .: "beds_covid"
            <*> record .: "beds_noncrit"
            <*> record .: "admitted_pui"
            <*> record .: "admitted_covid"
            <*> record .: "admitted_total"
            <*> record .: "discharged_pui"
            <*> record .: "discharged_covid"
            <*> record .: "discharged_total"
            <*> record .: "hosp_covid"
            <*> record .: "hosp_pui"
            <*> record .: "hosp_noncovid"

--Function to read hospital data from a csv file
readHospitalData :: FilePath -> IO (Either String (V.Vector HospitalDataset))
readHospitalData filePath = do 
    CSVData <- BL.readFile filePath
    return $ decodeByName CSVData --Decode by name uses the header row for named fields

-- Get total admitted based on category for a HospitalData record
admittedByCategory :: Category -> HospitalDataset -> Int
admittedByCategory Suspected   = admittedSuspected
admittedByCategory Probable    = admittedProbable
admittedByCategory CovidPositive = admittedCovid
admittedByCategory NonCovid    = admittedNonCovid

-- Sum admitted or discharged by category for all records
totalAdmittedByCategory :: Category -> V.Vector HospitalDataset -> Int
totalAdmittedByCategory category = V.sum . V.map (admittedByCategory category)

-- type ErrorMsg = String
-- --type sysnonym to handle CSV contents
-- type CSVData = (Header, V.Vector HospitalDataset)

-- filePath :: String
-- filePath = "hospital.csv"
-- --Funtion to read the CSV
-- parseCSV :: FilePath -> IO (Either ErrorMsg CSVData)
-- parseCSV filePath = do
--     fileExists <- doesFileExist filePath
--     if fileExists
--         then decodeByName <$> BL.readFile filePath
--         else return . Left $ printf "The file does not exist" filePath

-- --Remove the headers
-- removeHeader :: CSVData -> V.Vector HospitalDataset
-- removeHeader = snd

-- --Given a list, return only the elements with instrumentType "common stock"
-- filterStocks :: V.Vector HospitalDataset -> V.Vector HospitalDataset
-- filterStocks = filter isStock
--     where
--         isStock :: HospitalDataset -> Bool
--         isStock hospital = hospitalType hospital == "Common Stock"

-- --Read stocks from a CSV file
-- readStocks :: FilePath -> IO (Either ErrorMsg (V.Vector HospitalDataset))
-- readStocks filePath = 
--     (fmap . fmap) --lift the function twice
--         (filterStocks . removeHeader) --remove header and filter stocks
--             (parseCSV filePath) --read csv from filepath

main :: IO ()
main = do
    result <- readHospitalData "hospital.csv"
    case result of 
        Left err -> putStrLn $ "Error Parsing CSV: " ++ err
        Right hospitalData -> do
            let totalCovidAdmissions = totalAdmittedByCategory CovidPositive hospitalData
            putStrLn $ "Total COVID-19 Admissions: " ++ show totalCovidAdmissions

